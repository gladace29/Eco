# Project Title

A website that recommends eco-friendly products

## Getting Started

These instructions will give you a copy of the project up and running on
your local machine.

### Installing

A step by step series of examples that tell you how to get a development
environment running

Step 1:

    Download Zip file of the code
Step 2:

    Run Live server in VsCode or any other alternatives
  
Step 3:

    Run json-server --watch products.json

